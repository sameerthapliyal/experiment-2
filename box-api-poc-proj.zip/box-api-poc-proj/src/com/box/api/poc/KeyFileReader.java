package com.box.api.poc;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.Reader;
import java.util.Properties;

import com.box.sdk.BoxDeveloperEditionAPIConnection;
import com.box.sdk.BoxFile;
import com.box.sdk.BoxFolder;
import com.box.sdk.BoxItem;
import com.box.sdk.BoxUser;
import com.box.sdk.EncryptionAlgorithm;
import com.box.sdk.IAccessTokenCache;
import com.box.sdk.InMemoryLRUAccessTokenCache;
import com.box.sdk.JWTEncryptionPreferences;

public class KeyFileReader {
	
	static final int MAX_CACHE_ENTRIES = 100;

	public static void main(String[] args) throws Exception {

        File keyFile = new File("config.json");
        byte[] fileData = new byte[(int) keyFile.length()];
        DataInputStream dis = new DataInputStream(new FileInputStream(keyFile));
        dis.readFully(fileData);
        dis.close();

        String privateKey = new String(fileData);
        
        System.out.println("private key:"  + privateKey);
        
        Properties prop = new Properties();
    	InputStream input = null;
    	
        input = new FileInputStream("config.properties");
		// load a properties file
		prop.load(input);

		// get the property value and print it out
		System.out.println(prop.getProperty("boxClientId"));
		System.out.println(prop.getProperty("boxClientSecret"));
		System.out.println(prop.getProperty("boxEnterpriseId"));
		System.out.println(prop.getProperty("boxPrivateKeyFile"));
		System.out.println(prop.getProperty("boxPrivateKeyPassword"));
		System.out.println(prop.getProperty("boxPublicKeyId"));
		
		 final String ENTERPRISE_ID = ConfigHelper.properties().getProperty("boxEnterpriseId");
		 final String CLIENT_ID = ConfigHelper.properties().getProperty("boxClientId");
		 final String CLIENT_SECRET = ConfigHelper.properties().getProperty("boxClientSecret");
	//	 final String PRIVATE_KEY_FILE = ConfigHelper.properties().getProperty("boxPrivateKeyFile");
		 final String PRIVATE_KEY_PASSWORD = ConfigHelper.properties().getProperty("boxPrivateKeyPassword");
		 final String PUBLIC_KEY_ID = ConfigHelper.properties().getProperty("boxPublicKeyId");
		 
        JWTEncryptionPreferences encryptionPref = new JWTEncryptionPreferences();
        encryptionPref.setPublicKeyID(PUBLIC_KEY_ID);
        encryptionPref.setPrivateKey(privateKey);
        encryptionPref.setPrivateKeyPassword(PRIVATE_KEY_PASSWORD);
        encryptionPref.setEncryptionAlgorithm(EncryptionAlgorithm.RSA_SHA_256);

        IAccessTokenCache accessTokenCache = new InMemoryLRUAccessTokenCache(MAX_CACHE_ENTRIES);

        BoxDeveloperEditionAPIConnection api = BoxDeveloperEditionAPIConnection.getAppEnterpriseConnection(
                ENTERPRISE_ID, CLIENT_ID, CLIENT_SECRET, encryptionPref, accessTokenCache);

        BoxUser.Info userInfo = BoxUser.getCurrentUser(api).getInfo();
        System.out.format("Welcome, %s!\n\n", userInfo.getName());

        Iterable<com.box.sdk.BoxUser.Info> managedUsers = BoxUser.getAllEnterpriseUsers(api, "ken.domen@nike.com");
        for (BoxUser.Info managedUser : managedUsers) {
            System.out.println(managedUser.getName() + " " + managedUser.getStatus());
            if (managedUser.getStatus().equals(BoxUser.Status.ACTIVE)) {

                // BoxDeveloperEditionAPIConnection. getAppUserConnection() is used to get AppUser or ManagedUser
                // in this example, I'm getting a managedUser (ken.domen@nike.com)
                BoxDeveloperEditionAPIConnection userApi = BoxDeveloperEditionAPIConnection.getAppUserConnection(managedUser.getID(), CLIENT_ID, CLIENT_SECRET, encryptionPref, accessTokenCache);

                BoxFolder boxFolder = new BoxFolder(userApi, "0");
                Iterable<com.box.sdk.BoxItem.Info> items = boxFolder.getChildren();
                for (BoxItem.Info item : items) {
                    if (item instanceof BoxFile.Info) {
                        BoxFile.Info fileInto = (BoxFile.Info) item;
                        System.out.println("\t" + item.getName());
                    }
                }
            }
        }
    }
}
